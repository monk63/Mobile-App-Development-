//Michael Ofori
//Write the syntax for a ternary operation and explain it

public class question4 {

    public static void main(String [] args){

        int a=2,b=4,maximum;

        maximum = (a>b) ? a : b;

        System.out.println("Highest number is : "+maximum);

    }
    

    
}
