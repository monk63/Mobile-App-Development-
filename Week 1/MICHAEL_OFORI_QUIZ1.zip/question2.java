//Michael Ofori
//Write a piece of instructions/code that demonstrates the concept of using an external library in your application


import static java.lang.Math.sqrt;


public class question2 {
   public static void main(String[] arg) {
      double num = 36.0;
      System.out.println("square root is: " + sqrt(num));
   }
}