//Michael Ofori
//Write a function that takes two parameters and returns a computed result
public class question_3 {
    
    
    public static void add(int x,int y){
        int sum = x + y;
        
        System.out.println(+sum);
    }
   
    
}
