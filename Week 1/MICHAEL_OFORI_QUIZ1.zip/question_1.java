//Michael Ofori 
//Write a piece of instructions/code that demonstrates 
//the concept of local vs global variable

//local variable

public int multiply(){
    int x = 2;
    int y = 3;
    return x*y;
}

//Global variable
    int x = 2;
    int y = 3;
public int multiply(){

    return x*y;
}
