//Michael Ofori
//Write a piece of instructions/code that demonstrate the use of a loops. E.g. display an item on the screen 10 times.

public class question6 {
    
    public static void main(String [] args){
    for (int i = 0; i < 11; i++) {
        System.out.println(i);
      }
    }
}
