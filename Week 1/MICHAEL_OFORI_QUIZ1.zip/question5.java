//Michael ofori
//Write a piece of instructions/code that demonstrates the use of an instance of a class

public class question5 {
}
    class car{}

    class tyre extends car{
        
        public static void main (String args[]){
            tyre benz = new tyre();
            //instance of is used to compare variable and return true is they are the same.
            System.out.println(benz instanceof car);
        }
    }
    

